# Litecom Web Cleaned

This is a cleaned version of the Litecom Facebook Lite variant. Tracking-related files such as location, ad ID, and device ID components have been removed.

## Structure

- Contains Android-related property files
- No tracking libraries or identifiers
- Cleaned and ready to upload to GitHub

> This is not a functional app but a cleaned archive for inspection or adaptation.
